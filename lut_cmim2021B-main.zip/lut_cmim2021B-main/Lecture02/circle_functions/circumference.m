function C = circumference(r)

C = 2 * pi * r;

end