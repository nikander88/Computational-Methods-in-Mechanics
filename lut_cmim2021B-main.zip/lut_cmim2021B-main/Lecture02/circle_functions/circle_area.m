function A = circle_area(r)

A = pi .* r .* r;

end