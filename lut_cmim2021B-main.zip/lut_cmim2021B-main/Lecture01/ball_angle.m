x = 10; % horizontal position
y = 10; % vertical position

angle = atan(y / x);
(angle * 180) / pi
