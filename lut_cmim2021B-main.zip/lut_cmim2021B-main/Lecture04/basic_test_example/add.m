% The only practical purpose of this function is to present how to write
% tests (look at test_add.m)
function u = add(a, b)
    u = a + b;
end